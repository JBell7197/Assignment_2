import UIKit

import Foundation

func mortgagePaymentMonthly(loanAmount: Int, numberOfPayments: Int, interestRate: Float) -> Float {
    let monthlyInterestRate = interestRate / 12 / 100
    let numerator = Float(loanAmount) * monthlyInterestRate
    let denominator = 1 - pow(1 + monthlyInterestRate, -Float(numberOfPayments))
    
    let payment = numerator / denominator
    return payment
}

func mortgagePaymentAnnual(loanAmount: Int, numberOfPayments: Int, interestRate: Float) -> Float {
    let interestRate = interestRate / 100
    let numerator = Float(loanAmount) * interestRate
    let denominator = 1 - pow(1 + interestRate, -Float(numberOfPayments))
    
    let payment = numerator / denominator
    return payment
    
}

// 2-month loan of $20,000, 4.4% APR, compounded monthly
let payment1 = mortgagePaymentMonthly(loanAmount: 20000, numberOfPayments: 2, interestRate: 4.4)
print("$20,000 2-month loan with 4.4% APR compounded monthly payment: $\(String(format: "%.2f", payment1))")

// 30-year loan of $150,000, 5% APR, one annual payment each year for 30 years
let payment2 = mortgagePaymentAnnual(loanAmount: 150000, numberOfPayments: 30, interestRate: 5)
print("$150,000 30-year loan with 5% APR compounded annually payment: $\(String(format: "%.2f", payment2))")
